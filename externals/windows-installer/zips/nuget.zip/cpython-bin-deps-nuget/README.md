# cpython-bin-deps
Binaries that the cpython build process depends on
