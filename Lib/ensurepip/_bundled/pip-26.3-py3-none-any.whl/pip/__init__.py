from __future__ import annotations

__version__ = "26.3"

# External tools should import dependencies themselves. If technically unable,
# add names here, not to pip's internal list.
_EAGER_IMPORTS: set[str] = set()


def main(args: list[str] | None = None) -> int:
    """This is an internal API only meant for use by pip's own console scripts.

    For additional details, see https://github.com/pypa/pip/issues/7498.
    """
    from pip._internal.utils.entrypoints import _wrapper

    return _wrapper(args)
