attr = 'missing_directory foo two'
